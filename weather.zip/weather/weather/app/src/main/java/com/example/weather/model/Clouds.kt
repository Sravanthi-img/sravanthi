package com.example.weather.model

data class Clouds(
    val all: Int
)