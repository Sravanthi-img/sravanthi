package com.example.weather.model

data class Coord(
    val lat: Double,
    val lon: Double
)