package com.example.weather.model

data class Wind(
    val deg: Int,
    val speed: Double
)